package com.example.lab5;

import android.view.View;

public interface OnItemSelectedListener {
    void onListItemSelected(View sharedView, int image, String title, String year);
}
